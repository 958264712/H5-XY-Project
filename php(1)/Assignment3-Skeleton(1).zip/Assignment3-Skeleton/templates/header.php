<!-- 
    your code for the header goes here
    the header should contain the standard HTML head element including a link to your style sheet (style.css)
    you should incldue this file all your .php files using: include('templates/header.php');
-->