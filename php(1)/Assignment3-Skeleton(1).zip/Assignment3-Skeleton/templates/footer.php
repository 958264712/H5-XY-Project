<!-- 
	your code for footer goes here (this should be included on all pages) 
  	you should incldue this file all your .php files using: include('templates/header.php');
-->