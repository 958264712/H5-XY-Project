<!-- your code for the home page goes here -->

<?php

    require_once('config/db_connect.php');

?>

<h1>You are now ready to get started!</h1>